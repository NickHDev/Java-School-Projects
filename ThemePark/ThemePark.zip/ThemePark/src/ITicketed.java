public interface ITicketed {
    double defaultPrice();
    double priceFor(int Visitor);
}
