public interface ISecurity {
    boolean isAllowedTo(int Visitor);
}
