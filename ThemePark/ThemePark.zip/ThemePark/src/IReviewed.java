public interface IReviewed {
    int getRating();
    String getName();
}
