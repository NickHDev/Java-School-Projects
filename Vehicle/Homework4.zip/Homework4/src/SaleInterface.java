public interface SaleInterface {
    //methods to implement
    boolean transferOwnership(int buyer);
}
