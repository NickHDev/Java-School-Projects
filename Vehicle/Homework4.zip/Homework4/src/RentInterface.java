public interface RentInterface {
    //methods to implement
    boolean hireThis(int renter);
    boolean returnThis(int miles);
}
